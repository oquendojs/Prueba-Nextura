<?php

require_once "controladores/controlador.plantilla.php";
require_once "controladores/controlador.formularios.php";

require_once "modelos/modelo.formularios.php";

$plantilla = new ControladorPlantilla();
$plantilla -> ctrtraerplantilla();
