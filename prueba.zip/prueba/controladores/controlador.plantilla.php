<?php

Class ControladorPlantilla{

    public function ctrTraerplantilla(){

        include "vistas/plantilla.php";

    }

}