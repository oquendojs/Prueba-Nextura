<h1>404</h1>
<p>página no encontrada</p>
<a href="index.php?modulo=listaEmpleados">Inicio</a>